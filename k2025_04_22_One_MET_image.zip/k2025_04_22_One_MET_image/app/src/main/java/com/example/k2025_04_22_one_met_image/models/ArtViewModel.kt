package com.example.k2025_04_22_one_met_image.models

import android.util.Log
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import com.example.k2025_04_22_one_met_image.models.ArtObjectResponse
import com.example.k2025_04_22_one_met_image.services.RetrofitClient
import kotlinx.coroutines.flow.asStateFlow

class ArtViewModel : ViewModel() {
    private val _artList = MutableStateFlow<List<ArtObjectResponse>>(emptyList())
    val artList = _artList.asStateFlow()

    init {
        fetchArtObjects()
    }

    private fun fetchArtObjects() {
        viewModelScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.apiService.getAllObjectIDs()
                }
                Log.d("ArtViewModel", "# of IDs returned ${response.objectIDs.size}")
                val limitedIDs = response.objectIDs.take(50) // You can increase this

                val artObjects = limitedIDs.mapNotNull { id ->
                    try {
                        val artObject = RetrofitClient.apiService.getArtObjectById(id)
                        if (artObject.primaryImage.isNotEmpty()) {
                            Log.d("ArtViewModel", "Art returned: ${artObject.title}")
                            artObject
                        } else null
                    } catch (e: Exception) {
                        Log.e("ArtViewModel", "Error on object ID $id", e)
                        e.printStackTrace()
                        null
                    }
                }

                _artList.value = artObjects
                Log.d("ArtViewModel", "Filtered to ${artObjects.size} art with images")
                Log.d("ArtViewModel", "Loaded ${artObjects.size} art pieces")
            } catch (e: Exception) {
                Log.e("ArtViewModel", "Error !", e)
                e.printStackTrace()
            }
        }
    }
}