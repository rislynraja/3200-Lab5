package com.example.k2025_04_22_one_met_image.services

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl("https://collectionapi.metmuseum.org/") // public/collection/v1/
            .build()
            .create(ApiService::class.java)
    }
}