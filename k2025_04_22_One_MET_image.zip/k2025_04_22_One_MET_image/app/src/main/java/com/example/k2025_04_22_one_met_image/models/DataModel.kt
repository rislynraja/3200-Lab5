package com.example.k2025_04_22_one_met_image.models

data class ObjectIDsResponse( // first for getting the id list
    val total: Int,
    val objectIDs: List<Int>
)

data class ArtObjectResponse( // then, for each individual id getting this info
    val objectID: Int,
    val title: String,
    val artistDisplayName: String,
    val primaryImage: String
)
