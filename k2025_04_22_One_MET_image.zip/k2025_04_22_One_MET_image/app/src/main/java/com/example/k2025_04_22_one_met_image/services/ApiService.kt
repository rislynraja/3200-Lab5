package com.example.k2025_04_22_one_met_image.services

import com.example.k2025_04_22_one_met_image.models.ArtObjectResponse
import com.example.k2025_04_22_one_met_image.models.ObjectIDsResponse
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService { // narrowing search params for less ids
    @GET("public/collection/v1/search?q=landscape&hasImages=true") // search?q=landscape&hasImages=true
    suspend fun getAllObjectIDs(): ObjectIDsResponse

    @GET("public/collection/v1/objects/{objectID}")
    suspend fun getArtObjectById(@Path("objectID") objectID: Int): ArtObjectResponse
}