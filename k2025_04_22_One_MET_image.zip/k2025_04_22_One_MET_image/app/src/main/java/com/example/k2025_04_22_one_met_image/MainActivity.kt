package com.example.k2025_04_22_one_met_image

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.k2025_04_22_one_met_image.ui.theme.METViewerTheme
import com.example.k2025_04_22_one_met_image.models.ArtViewModel

class MainActivity : ComponentActivity() {
    private val artViewModel: ArtViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            METViewerTheme {
                MetImageViewerApp(artViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetImageViewerApp(artViewModel: ArtViewModel) {
    val artList by artViewModel.artList.collectAsState()
    var currentIndex by remember { mutableStateOf(0) }
    val currentArt = artList.getOrNull(currentIndex)

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(
                "Welcome to the MET Mobile Gallery !",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            })
        },
        content = { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    when {
                        currentArt == null -> {
                            CircularProgressIndicator() // to show loading
                        }
                        currentArt.primaryImage.isEmpty() -> {
                            Text(
                                "No image available for this artwork.",
                                fontSize = 18.sp,
                                color = Color.Red,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        else -> {
                            AsyncImage(
                                model = currentArt.primaryImage,
                                contentDescription = currentArt.title,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(0.55f)
                                    .clip(RoundedCornerShape(16.dp))
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text( // TITLE OF ART PIECE
                        text = currentArt?.title ?: "",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text( // ARTIST OF ART PIECE
                        text = currentArt?.artistDisplayName ?: "",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button( // prev button (should only enable once you've already moved to the next one
                            onClick = { if (currentIndex > 0) currentIndex-- },
                            enabled = currentIndex > 0
                        ) {
                            Text("Previous")
                        }
                        Button( // next button
                            onClick = { if (currentIndex < artList.size - 1) currentIndex++ },
                            enabled = currentIndex < artList.size - 1
                        ) {
                            Text("Next")
                        }
                    }
                }
            }
        }
    )
}

